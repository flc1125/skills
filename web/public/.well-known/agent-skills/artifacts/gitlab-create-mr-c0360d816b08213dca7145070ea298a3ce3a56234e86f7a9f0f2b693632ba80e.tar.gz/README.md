# gitlab-create-mr

Local Codex skill for drafting and creating GitLab merge requests.

## Install

```bash
npx skills add https://skills.flc.io --skill gitlab-create-mr
```

If the custom skill source is temporarily unavailable, install from GitHub:

```bash
npx skills add https://github.com/flc1125/skills --skill gitlab-create-mr
```

## Scope

- Check branch status and likely MR base
- Detect the correct GitLab host for GitLab.com or self-managed instances
- Analyze commits and diff before drafting the MR
- Draft a clear merge request title and description
- Document breaking changes, before-and-after comparisons, and migration steps when needed
- Create the merge request with `glab`
- Reuse a local MR body conventions document for consistent descriptions

## Structure

```text
gitlab-create-mr/
├── SKILL.md
├── README.md
├── agents/
│   └── openai.yaml
└── references/
    ├── breaking-change-conventions.md
    ├── mr-body-conventions.md
    └── verified-commands.md
```

## Notes

- This skill is designed to run independently.
- It supports both `gitlab.com` and self-managed GitLab instances.
- It focuses on merge request creation only and does not handle reviewer assignment.

# github-create-pr

Local Codex skill for preparing and creating GitHub pull requests.

## Install

```bash
npx skills add https://skills.flc.io --skill github-create-pr
```

If the custom skill source is temporarily unavailable, install from GitHub:

```bash
npx skills add https://github.com/flc1125/skills --skill github-create-pr
```

## Scope

- Check branch status and PR base
- Analyze commits and diff
- Draft a clear PR title and body
- Document breaking changes, before-and-after comparisons, and migration steps when needed
- Create or update a PR with `gh`
- Add reviewers when needed

## Structure

```text
github-create-pr/
├── SKILL.md
├── README.md
├── agents/
│   └── openai.yaml
└── references/
    ├── breaking-change-conventions.md
    └── pr-body-conventions.md
```

## Source Attribution

This skill is a localized adaptation of the following upstream skill:

- Source: `getsentry/skills`
- Upstream path: `plugins/sentry-skills/skills/pr-writer/SKILL.md`
- URL: <https://github.com/getsentry/skills/blob/main/plugins/sentry-skills/skills/pr-writer/SKILL.md>

## Notes

This version is not a verbatim copy of the upstream content. It was rewritten to match this repository's local skill conventions:

- The skill name was changed to `github-create-pr`
- Sentry-specific language was generalized into a GitHub PR workflow
- The output structure and metadata were adapted to the local Codex skill format
- PR body conventions were moved into a local reference file for easier maintenance
